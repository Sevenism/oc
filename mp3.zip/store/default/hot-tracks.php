<?php
$json_string = 'https://rss.itunes.apple.com/api/v1/id/apple-music/hot-tracks/all/100/explicit.json';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
$cltn = $obj['feed']['results'][0]['collectionName'];
$hot = "";
foreach ($obj['feed']['results'] as $result) {
//echo $result['name'] . '<br>' . PHP_EOL;
$hot = $hot . $result['name'] . "\n";
}
file_put_contents('store/default/keywords/3.txt', $hot);
?>