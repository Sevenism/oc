<?php
$json_string = 'https://rss.itunes.apple.com/api/v1/id/apple-music/new-releases/all/100/explicit.json';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
$new = "";
foreach ($obj['feed']['results'] as $result) {
//echo $result['name'] . '<br>' . PHP_EOL;
$new = $new . $result['name'] . "\n";
}
file_put_contents('store/default/keywords/5.txt', $new);
?>